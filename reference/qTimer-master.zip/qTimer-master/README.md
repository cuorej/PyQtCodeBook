# qTimer
A simple stopwatch app built in Python with Qt5.

Usage: Download a binary and run it. Alternatively, clone this repository and run `python3 src/main/python/main.py`.
